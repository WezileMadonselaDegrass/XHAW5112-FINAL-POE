package com.example.nextlevelgaming.models

object MockData {
    val packages = listOf(
        GamingPackage(
            id = 1,
            name = "Casual Gaming Session",
            price = 35.0,
            duration = "2 hours",
            players = "1–4 players",
            tag = "Jump in and play.",
            badge = "Best value",
            categories = listOf("Individual", "Family"),
            inclusions = listOf("2 hours high-spec station", "Full library access", "Headset hire")
        ),
        GamingPackage(
            id = 2,
            name = "Competitive Training Pack",
            price = 65.0,
            duration = "3 hours",
            players = "1–10 players",
            tag = "Level up your skills.",
            badge = null,
            categories = listOf("Esports", "Club"),
            inclusions = listOf("3 hours practice", "Coach-led drills", "Low-latency stations")
        ),
        GamingPackage(
            id = 3,
            name = "Birthday Party Package",
            price = 85.0,
            duration = "3 hours",
            players = "6–20 players",
            tag = "Make it legendary.",
            badge = "Popular",
            categories = listOf("Birthday", "Family"),
            inclusions = listOf("Party zone", "Dedicated host", "Mini tournament")
        ),
        GamingPackage(
            id = 4,
            name = "Family Play Session",
            price = 40.0,
            duration = "2 hours",
            players = "2–6 players",
            tag = "Everyone plays.",
            badge = null,
            categories = listOf("Family", "Individual"),
            inclusions = listOf("Family lounge", "Age-friendly games", "Co-op stations")
        ),
        GamingPackage(
            id = 5,
            name = "School Group Session",
            price = 45.0,
            duration = "3 hours",
            players = "10–40 players",
            tag = "Learn, play, connect.",
            badge = null,
            categories = listOf("School"),
            inclusions = listOf("Teamwork games", "Esports talk", "Supervision included")
        ),
        GamingPackage(
            id = 6,
            name = "Corporate Team Challenge",
            price = 95.0,
            duration = "3 hours",
            players = "8–40 players",
            tag = "Beat the boardroom.",
            badge = null,
            categories = listOf("Corporate"),
            inclusions = listOf("Private arena hire", "Live commentator", "Team-building formats")
        )
    )
}