package com.example.nextlevelgaming

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.nextlevelgaming.models.GamingPackage
import com.example.nextlevelgaming.ui.theme.CardBg
import com.example.nextlevelgaming.ui.theme.DarkBg
import com.example.nextlevelgaming.ui.theme.NeonCyan
import com.example.nextlevelgaming.ui.theme.NeonPink
import com.example.nextlevelgaming.ui.theme.NeonPurple
import com.example.nextlevelgaming.ui.theme.NextLevelGamingTheme
import com.example.nextlevelgaming.viewmodels.ArenaViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel = ArenaViewModel()
            val navController = rememberNavController()

            NextLevelGamingTheme {
                Scaffold(
                    containerColor = DarkBg,
                    bottomBar = {
                        GamingBottomBar(navController)
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "home",
                        modifier = Modifier
                            .fillMaxSize()
                            .background(DarkBg)
                            .padding(innerPadding)
                    ) {
                        composable("home") { HomeScreen(viewModel) }
                        composable("packages") { PackagesScreen(viewModel.packages) }
                        composable("calculator") { CalculatorScreen() }
                        composable("about") { AboutScreen() }
                        composable("contact") { ContactScreen() }
                    }
                }
            }
        }
    }
}

@Composable
private fun GamingBottomBar(navController: NavHostController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar(containerColor = CardBg) {
        listOf(
            "Home" to Icons.Default.Home,
            "Packages" to Icons.Default.Games,
            "Calculator" to Icons.Default.AttachMoney,
            "About" to Icons.Default.Info,
            "Contact" to Icons.Default.Mail
        ).forEach { (screen, icon) ->
            NavigationBarItem(
                selected = currentRoute == screen.lowercase(),
                onClick = { navController.navigate(screen.lowercase()) },
                icon = { Icon(icon, contentDescription = screen) },
                label = { Text(screen) }
            )
        }
    }
}

@Composable
private fun HomeScreen(viewModel: ArenaViewModel) {
    val featuredPackage = viewModel.packages.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "NEXT LEVEL GAMING",
                style = MaterialTheme.typography.headlineMedium,
                color = NeonCyan,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Private gaming areas, tournaments, and premium party packages.",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFF475467)
            )
        }

        item {
            if (featuredPackage != null) {
                FeaturedPackageCard(featuredPackage)
            }
        }

        item {
            Text(
                text = "Popular picks",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.SemiBold
            )
        }

        items(viewModel.packages.take(4)) { packageItem ->
            PackageListItem(packageItem)
        }
    }
}

@Composable
private fun FeaturedPackageCard(gamingPackage: GamingPackage) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(NeonPurple, NeonPink)
                    )
                )
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Featured package",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                Badge(containerColor = Color.White.copy(alpha = 0.15f)) {
                    Text(text = gamingPackage.badge ?: "Popular", color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = gamingPackage.name,
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = gamingPackage.tag,
                color = Color.White.copy(alpha = 0.8f),
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "$${gamingPackage.price}",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = gamingPackage.duration,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
private fun PackagesScreen(packages: List<GamingPackage>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Gaming packages",
                style = MaterialTheme.typography.headlineMedium,
                color = NeonCyan,
                fontWeight = FontWeight.Bold
            )
        }

        items(packages) { packageItem ->
            PackageListItem(packageItem)
        }
    }
}

@Composable
private fun PackageListItem(gamingPackage: GamingPackage) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = gamingPackage.name,
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "$${gamingPackage.price}",
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = gamingPackage.players,
                color = Color(0xFFB7BED5)
            )
            Text(
                text = gamingPackage.duration,
                color = Color(0xFFB7BED5)
            )
            Spacer(modifier = Modifier.height(12.dp))
            gamingPackage.categories.forEach { category ->
                Text(
                    text = "• $category",
                    color = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.padding(bottom = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            Spacer(modifier = Modifier.height(12.dp))

            gamingPackage.inclusions.forEach { inclusion ->
                Text(
                    text = "✓ $inclusion",
                    color = Color(0xFF9EEAFF),
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun CalculatorScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Calculator",
            style = MaterialTheme.typography.headlineMedium,
            color = NeonCyan,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = "Add the total for your next gaming session here.",
            color = Color(0xFF475467)
        )
        Spacer(modifier = Modifier.height(20.dp))
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(text = "Estimated total", color = Color.White.copy(alpha = 0.7f))
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "$175.00", style = MaterialTheme.typography.headlineLarge, color = Color.White)
            }
        }
    }
}

@Composable
private fun AboutScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "About us",
            style = MaterialTheme.typography.headlineMedium,
            color = NeonCyan,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "NEXT LEVEL GAMING creates premium esports, party, and social gaming experiences with high-performance gear and tailored sessions.",
            color = Color(0xFF475467)
        )
    }
}

@Composable
private fun ContactScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Contact",
            style = MaterialTheme.typography.headlineMedium,
            color = NeonCyan,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(text = "hello@nextlevelgaming.com", color = Color(0xFF101828))
        Text(text = "+27 21 555 0123", color = Color(0xFF101828))
        Text(text = "Cape Town, South Africa", color = Color(0xFF101828))
    }
}
