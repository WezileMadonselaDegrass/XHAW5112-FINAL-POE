package com.example.nextlevelgaming.models

data class GamingPackage(
    val id: Int,
    val name: String,
    val price: Double,
    val duration: String,
    val players: String,
    val tag: String,
    val badge: String? = null,
    val categories: List<String>,
    val inclusions: List<String>
)