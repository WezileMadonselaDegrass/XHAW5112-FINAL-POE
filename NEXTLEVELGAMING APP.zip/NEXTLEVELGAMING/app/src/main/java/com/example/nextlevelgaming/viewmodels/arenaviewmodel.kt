package com.example.nextlevelgaming.viewmodels

import androidx.lifecycle.ViewModel
import com.example.nextlevelgaming.models.MockData

class ArenaViewModel : ViewModel() {
    val packages = MockData.packages
}